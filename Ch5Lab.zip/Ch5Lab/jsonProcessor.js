"use strict"



$( function() {
	console.log("Getting Here!");
	
});